document.getElementById('smsForm').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const phoneNumber = document.getElementById('phoneNumber').value;
    const message = document.getElementById('message').value;
  
    // Here you would typically make an AJAX request to your backend to send the SMS
    // For example, using fetch API or XMLHttpRequest
  
    // Simulated response for demonstration purposes
    const response = { success: true, message: 'SMS sent successfully.' };
  
    displayResponse(response);
  });
  
  function displayResponse(response) {
    const responseDiv = document.getElementById('response');
    responseDiv.innerHTML = response.success
      ? <div class="success">${response.message}</div>
      : <div class="error">${response.message}</div>;
  }